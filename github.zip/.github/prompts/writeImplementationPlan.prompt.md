---
description: 'Create an implementation plan for an ADR with files to be changed and references to supporting documentation or existing files'
---

# Write Implementation Plan for ADR

Your goal is to create a reproducable implementation plan for a given ADR. The plan should outline all necessary changes to the codebase, including new files to be created, existing files to be modified, and references to supporting documentation or existing files that can serve as patterns.

Consider that the output document will be used by AI Agents to implement the changes and as support for future implementations. It will also be used by human reviewers to validate the implementation.

## Output

You need to write a new markdown file named `<ADR-ID>.implementation-plan.md`, where `<ADR-ID>` is the ID of the ADR you are creating the implementation plan for. The file should be placed in the same directory as the ADR.

### Document Format

The implementation plan document must include the following sections:

---
### 1. Database Changes
**Optional:** If not necessary, write "None required for this implementation."

#### Content:
**Description:** 1 sentence describing why database changes are needed, if any.
**Migrations:** 
- List the files to be created with their paths and brief descriptions. Use "Create file:" for new files.
- When its a DDL script, include the coluns affected.
- Include any indexes to be created.
- When acting on existing tables or values, describe mitigation and rollback procedures.
- For updates to existing files (e.g., master changelog), use "Update file:" followed by the path and description of changes.

### 2. Library Changes
**Optional:** If not necessary, write "None required for this implementation."

#### Content:
Describe the rationale for any new libraries or upgrades, including why existing libraries cannot fulfill the need.

### 3. Source Code Changes
**Optional:** If not necessary, write "None required for this implementation."

#### Content:
- Organize the new and changed classes by architectural layer: 1) Presentation, 2) Domain, 3) Application, 4) Infrastructure.
- For application layer interfaces, include methods from the use case interfaces.
- For domain layer repository interfaces, include methods from the repository interfaces.
- On each layer, list all new and changed classes with their full paths.
- For each class, add references to documentation or existing files that should be used as patterns.
- Do not include code implementations.
- When any file inside `resources` is changed, describe the purpose and impact of the change.

### 4. Test Code Changes
**Optional:** If not necessary, write "None required for this implementation."

#### Content:
- List all new and changed test classes with their full paths.
- For each test file, add references to documentation or existing files that should be used as patterns.
- Include the title of the scenarios for each file.
- Include the type of tests: Unit, BDD, Contract.
- Include references to fixtures or test data inside resources.

### 5. Documentation Changes
**Optional:** If not necessary, write "None required for this implementation."

#### Content:
- List all new and changed documentation files with their full paths.
- For each documentation file, add references to existing files that should be used as patterns.
- Include references to any external documentation that should be updated.

---

## Output Validation

- Ensure that the implementation plan is clear, concise, and free of ambiguity.
- Verify that all necessary sections are included and properly formatted.
- Confirm that all referenced files and documentation exist and are accessible.
- Check for consistency in terminology and style throughout the document.
- Validate that the plan aligns with the goals and constraints outlined in the ADR.