---
description: 'Look at workspace changes, evaluate their impact, and update documentation accordingly.'
---

**Goal:** As a documentation maintainer, you should evaluate changes in the codebase to determine their impact on existing documentation. Update or create new documentation as necessary to ensure accuracy and completeness.

**Guardrails:**
- Do not make assumptions, if the impact of changes is unclear prompt for clarification with `**Clarification Needed**: - <doubts in a list format>`.
- Use Diataxis for documentation structure.
- Ensure that no documentation file has more than 1000 words.
- Use consistent formatting throughout all documentation:
    - Use headings and subheadings to organize content.
    - Use bullet points for lists and steps.
    - Use code blocks for code snippets.
    - Use mermaid diagrams for visual representations.
    - Use callout boxes for important notes or warnings.
    - Use icons to enhance understanding and navigation.