**Guardrails:**
- Never make assumptions. If information is ambiguous, incomplete, or referenced files are missing/unavailable, halt analysis and use the escalation template: `**Clarification Needed:** - <List of ambiguities>`.
- Search `/docs/about` and `/docs/features` folders to find supporting documentation for the user's request.
- Prioritize the use of the available MCP tools to gather information.
- Always include a reference to the documentation which you used for your analysis as close as possible to the content you are addressing. For example, `using ValidityPeriod as per docs/about/reference/RelevantDomainClasses.md`.
- When using `./gradlew format`, always use with `--rerun-tasks` flag to ensure the latest code is built.