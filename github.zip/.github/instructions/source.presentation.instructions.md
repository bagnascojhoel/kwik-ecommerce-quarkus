---
applyTo: '**/src/**/presentation/**/*.java'
---
# Presentation Layer Instructions

This document outlines the standards and conventions for files in the presentation layer of the setup-central project.

## Controllers
- Keep controllers thin: input validation → call use case → map domain to response DTO.
- Annotate with `@RestController`, group tags using existing Swagger Tags (`SwaggerTags`).
- Reuse existing request/response DTO package versioning (v0, v1, v2...). Never break existing versioned contracts.

## DTOs & Mapping
- Locate DTOs under `presentation.api.v{n}` packages following existing pattern.
- Provide `fromDomain()` / `toDomain()` static factories instead of manual inline mapping.
- Keep enums & identifiers as strings only at boundary; convert immediately inside.

### DTO Mapping Requirements
For all presentation layer changes:
1. **Request DTOs** must have:
   - `@NotBlank`, `@Valid`, `@NotNull` validation annotations
   - `DomainObject toDomain()` static factory method
   - Package: `presentation.api.v{n}.request`
2. **Response DTOs** must have:
   - `static ResponseDTO fromDomain(DomainObject obj)` factory method
   - Package: `presentation.api.v{n}.response`
   - JSON property names matching API contract
3. **Versioning rules**:
   - Never break existing versioned contracts (v0, v1, v2)
   - Add new version for breaking changes
   - Document migration guide in JavaDoc when versioning

### Mapping Guidelines
- **Each DTO class must contain BOTH mapping methods**:
  - `toDomain()` – instance method to convert DTO to domain (for request DTOs)
  - `static fromDomain(DomainObject obj)` – static factory to convert domain to DTO (for response DTOs)
- Domain classes should NOT contain any DTO mapping methods – all mapping logic belongs in the presentation layer only.
- Use streams for collections: `list.stream().map(ResponseDto::fromDomain).toList()`
- Use `Optional` in domain objects for nullable fields; map `Optional.empty()` to `null` or omit field when converting to DTO (per API contract)
- Avoid separate mapper classes, splitting mapping methods between layers, or business logic inside mapping methods.

## Presentation Layer Error Handling
- Map exceptions to HTTP status codes via `@ControllerAdvice`

## Controller Layer Validation
- Use Jakarta validation: `@NotBlank`, `@NotNull`, `@Size`, `@Pattern`, `@Valid`
- Define regex patterns for format validation (e.g., OID format, country codes)
- Max string lengths aligned with database