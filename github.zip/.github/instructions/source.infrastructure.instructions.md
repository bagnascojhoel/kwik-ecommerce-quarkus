---
applyTo: '**/src/main/java/**/infrastructure/**/*.java'
---
# Infrastructure Layer Instructions
The infrastructure layer handles external concerns: database persistence (JPA entities, repositories), REST clients, message queues, and external adapters. It implements domain/application ports using external technologies.

## Key Rules
- **Dependencies**: Domain + application + external libs (Spring, JPA, etc.). No direct controller calls.
- **Entities**: Use `*Entity` classes; treat as immutable (no mutations post-creation). Use builder pattern. Prefer value objects over primitives. Set audit fields (createdAt/By, updatedAt/By) via `fromDomain()` with actor.
- **Repositories**: Use adapters implementing domain interfaces. No @Transactional. Prefer derived queries or Specifications for complex queries.
- **Specifications**: Create interfaces with `getSpecificationFactory()` and default `getSpecification(Request)` methods. Use `Filter.of()`, `Filter.ofDateIntersection()`, etc., with null checks.
- **Mapping**: Entities have `toDomain()` (instance) and `fromDomain(Domain, AssociateOid actor)` (static). No mappings in domain classes. Focus on structural transformation.
- **Performance**: Use LAZY fetching; paginate large sets (default 20, max 100); prevent N+1 with @EntityGraph; cache idempotent, read-heavy data with Caffeine (TTL/size bounds).
- **Exceptions**: Let domain exceptions bubble up; no translation in infrastructure.
- **Result Pattern**: Use for external calls that may fail without throwing. Check `isSuccess()` before `getSuccess()`; use `map()`/`flatMap()` for transformations.
- **REST Clients**: Use circuit breakers, timeouts; map DTOs to domain in adapters.
- **Naming**: `<Concept>RepositoryAdapter`, `<Concept>Entity`, `<Concept>EntitySpecification`, `<Service>RestClient`.
- **Testing**: Unit tests for mappings; integration with Testcontainers; WireMock for REST.

## Patterns
- **Repository Adapter**: Stateless, implements domain repo + spec interface. Uses `SpecificationFactory` for queries.
- **Entity Mapping**: `toDomain()` converts entity to domain; `fromDomain()` creates entity with audit (actor required).
- **Specification**: Default method builds filters with null safety; uses JPA metamodel for type safety.
- **Caching**: Only for immutable, frequent reads (>100/min, <1/hr changes, >50ms cost). No mutable/user-specific data.
- **Result Handling**: For external ops; handle warnings; transform with `map()`/`flatMap()`.

Follow these for consistent, performant infrastructure code aligned with domain-driven