---
applyTo: '**/test/**/*.feature, **/test/**/components/cucumber/**/*.java'
---

## Test Instructions
Write maintainable automated tests covering functionality and edge cases using appropriate strategies (unit, integration, component, contract). Follow Given-When-Then structure for behavior testing.

## Testing Priorities
3. **Component Tests/BDD Tests**: Test infrastructure with real dependencies (database/cache). Use Spring Boot Test + Testcontainers.

## Frameworks
- **Spring Boot Test**: Full context with `@SpringBootTest`.
- **Testcontainers**: Docker-based testing; use `@Testcontainers` + `@Container` for databases.
- **Cucumber**: BDD with `.feature` files and step definitions; integrate with `@CucumberContextConfiguration`.

## Maintainability
- Use fixtures for test data; leverage `.toBuilder()` for variations.
- Group tests by method with `@Nested` classes.

## Key Patterns
- **BDD Test**: Business-focused `.feature` files; step definitions use REST API.
- **Scenario Numbering**: Number scenarios sequentially starting from 1 (e.g., `Scenario: 1. Creating payroll activities`) for better organization and reference.
- **Step Class Naming**: Follow the pattern `<MainEntity>Step` (e.g., `PayrollActivityStep`, `ClientPolicyInstanceStep`).
- **HTTP Operations**: Reuse `CommonActionsStep` for WHEN steps that make HTTP requests (POST, GET, PUT, DELETE). Use `CommonValidationStep` for THEN steps that check HTTP status codes.
- **Data Table Conversion**: Use `@DataTableType` annotated methods in step classes to convert DataTable entries to domain objects, especially for complex JSON structures.
- **Repository Access**: 
  - Inject JPA repositories directly in step classes for simple entities with no complex relationships.
  - Use existing `*ServiceData` classes only when they provide complex setup logic (coordinating multiple repositories, setting nested entity properties).
  - DO NOT create new `*ServiceData` wrapper classes that simply delegate to a single repository - this is an anti-pattern.
- **Cleanup**: Use `@Before` hooks with feature tags for test data cleanup (e.g., `@Before("@FeatureTag")`).

## Test Data
- **BDD**: Persistent test database.
- **Repository Usage Guidelines**:
  - Simple entities: Use JPA repository directly
  - Complex entities with relationships: Reuse existing `*ServiceData` if available
  - Avoid creating unnecessary abstraction layers

## Execution
- All tests: `./gradlew cucumberFeatureTest`
- Contract tests: `./gradlew contractTest`
- Validation: `./gradlew compileTestJava checkstyleTest checkstyleContractTest`
- Coverage: `./gradlew test jacocoTestReport`