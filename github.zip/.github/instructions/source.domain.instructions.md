---
applyTo: '**/src/**/domain/**/*.java'
---
## Domain Layer Instructions
- Use `@Value` from Lombok for immutable domain objects with `private final` fields. Avoid mutability unless explicitly required.
- Follow existing patterns for domain IDs: Simple `@Value` classes implementing `DomainId<String>` with an `of()` factory method.
- Keep validation minimal in constructors/factories: Basic null checks and format validation only.
- Throw domain-specific exceptions from `domain.error` hierarchy for business rule violations.
- Use value objects to encapsulate validation logic.
- Implement repository interfaces in the domain layer; implementations belong in infrastructure.

## Class Patterns
- **DomainId.java**: `@Value` class implementing `DomainId<String>` with `of()` factory.
- **Entity.java**: `@Value @Builder` for complex entities with business methods.
- **ValueObject.java**: `@Value` for simple encapsulations.
- **RepositoryInterface.java**: Defines data access operations (e.g., `findById`, `save`); implemented in