---
applyTo: '**/contractTest/**, **/test/**/contracts/**'
---

## Test Instructions
Write contract tests to verify API contracts and ensure compatibility between producers and consumers. Use Spring Cloud Contract for defining and testing contracts.

## Testing Priorities
4. **Contract Tests**: Verify API contracts. Use Spring Cloud Contract + WireMock when APIs change.

## Frameworks
- **Spring Cloud Contract**: Define contracts in Groovy DSL under `src/contractTest/resources/contracts/`.
- **WireMock**: For stubbing external services in consumer tests.

## Maintainability
- Use fixtures for test data; leverage `.toBuilder()` for variations.
- Group tests by method with `@Nested` classes.
- Name tests: `given<Context>_when<Behavior>_then<ExpectedOutcome>`.
- Use `actual` for results, `expected` for expectations.

## Key Patterns
- **Contract Test**: Define in Groovy DSL; base classes extend `AbstractContractBase`.
- **Contract Definitions**: Written in Groovy DSL; do not manually modify generated Java classes in the build directory.
- **Consumer Contracts**: Test external service integrations (e.g., `LeaveMetadataServiceContractTest.java`).
- **Internal Contracts**: Test internal API contracts (e.g., `V1GetClientPolicyInstancesBase.java`); mock application services/use cases calls.
- Structure: Contracts in `src/contractTest/resources/contracts/`; test classes in `src/test/java/.../contracts/`.

## Naming Conventions
- **Contract Files**: Use snake_case for filenames, e.g., `get_client_policy_instances.groovy`.
- **Folders**: Group contracts by endpoint in folders named in camelCase, e.g., `getClientPolicyInstances/`.
- **Contract Names**: Descriptive within the Groovy file, e.g., 'Get client policy instances'.

## Test Data
- Use contract-defined data or fixtures.

## Pagination
- **Paginated Endpoints**: Use `PaginationMeta` structure for `_meta` field in responses:
  - `startSequence`: $(p(0), c(anyAlphaNumeric())) - Starting position in result set
  - `completeIndicator`: $(p(true), c(boolean)) - Whether all results returned
  - `totalNumber`: $(p(1), c(anyAlphaNumeric())) - Total count of items
  - Optional `links` array with navigation links (previous/next)
- Do NOT use Spring Data Page fields (`page`, `size`, `totalElements`, `totalPages`, `numberOfElements`, `first`, `last`, `empty`)
- Reference: `com.adp.pi.setupcentral.presentation.pagination.PaginationMeta`

## Execution
- Contract tests: `./gradlew contractTest`
- Validation: `./gradlew compileTestJava checkstyleTest checkstyleContractTest`
- Coverage: `./gradlew test jacocoTestReport`