# Application Layer Instructions

The application layer (`src/main/java/com/adp/pi/setupcentral/application`) orchestrates domain services and exposes use cases. It acts as the coordination layer between domain logic and infrastructure.

## File Types

### UseCase Interfaces
- **Naming:** `[Domain]UseCase.java` (e.g., `ClientUseCase.java`)
- **Package:** `com.adp.pi.setupcentral.application`
- Pure interfaces with method signatures only
- No annotations, implementations, or fields
- Methods represent high-level business operations

```java
public interface ClientUseCase {
    Client onboardClient(Client client, AssociateOid associateOid);
    List<Client> getClientConfigurations(OrganizationOid organizationOid);
}
```

### AdapterUseCase Implementations
- **Naming:** `[Domain]AdapterUseCase.java` (e.g., `ClientAdapterUseCase.java`)
- **Package:** `com.adp.pi.setupcentral.application`
- Use `@Service`, `@RequiredArgsConstructor`, `@Slf4j`
- Private final fields for injected dependencies
- Use `@Transactional` for write operations
- Throw domain exceptions (`ResourceNotFoundException`, `SetupCentralException`)

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class ClientAdapterUseCase implements ClientUseCase {
    private final ClientRepositoryService clientRepositoryService;
    
    @Override
    @Transactional
    public Client onboardClient(Client client, AssociateOid associateOid) {
        // Validation and orchestration logic
    }
}
```

### Configuration Classes
- **Naming:** `[Feature]Config.java` (e.g., `CacheConfig.java`)
- **Package:** `com.adp.pi.setupcentral.application.config`
- Use `@Configuration` and feature-specific annotations
- Define `@Bean` methods for infrastructure setup
- Use `@Value` for configurable properties
- No business logic

### Metrics Classes
- **Package:** `com.adp.pi.setupcentral.application.metrics`
- For configs: Use `@Configuration` with `@Import`
- For constants: Nested static classes with final strings
- Use `@NoArgsConstructor(access = AccessLevel.PRIVATE)` for utility classes

## General Standards
- Application layer depends on domain services only
- Avoid direct infrastructure or presentation layer references
- Use domain exceptions, not generic exceptions
- Stateless services with constructor injection
- Validate inputs early
- Use `@Transactional` for write operations
- Add `@SuppressWarnings` for justified PMD/Sonar suppressions

## Error Handling
Catch domain exceptions, enrich with context, then re-throw or wrap.

## Logging
Use SLF4J with `@Slf4j` annotation. Log at DEBUG level for flow, WARN for validation failures.

```java
log.atDebug().log("Executing use case with ID: {}", id);
log.atWarn().log("Validation failed: {}", error.getMessage());
```
