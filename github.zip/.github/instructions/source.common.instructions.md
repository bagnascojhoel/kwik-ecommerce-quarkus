---
applyTo: '**/src/**/*.java'
---
# Copilot Coding Instructions (Setup Central)

## Project Overview
Java 21, Spring Boot 3.4.2, Gradle 8.11. Domain-driven layered architecture: domain (pure business logic), application (use cases), infrastructure (adapters), presentation (controllers/DTOs). Focus: payroll policy setup (client, business, statutory, withholding) and configuration. Persistence: JPA/Hibernate, MariaDB, Liquibase. Caching: Caffeine. Security: ADP PI OAuth2. Observability: Micrometer + service-observability.

## Layering & Boundaries
- Domain: Only domain & JDK; no Spring/infrastructure.
- Application: Domain + ports; no direct JPA/entities.
- Infrastructure: Domain + application + externals; no direct controllers.
- Presentation: Application + DTOs; no entities.
Enforce: Controllers → UseCases → Ports → Adapters → DB/external. No layer violations.

## Validation
- Jakarta annotations (@NotBlank, @Valid) on controllers only.
- Domain: Business invariants via methods (e.g., validate()), not constructors/builders.
- No JavaDoc unless requested for public APIs.

## Error Handling
- Use AppExceptionHandler and existing hierarchy (ResourceNotFoundException, etc.).
- Provide meaningful codes via MessageCode/Result.

## Security & Auth
- Auth via ADP PI OAuth2; no manual parsing.
- Actor identity: @RequestHeader("associateoid") → AssociateOid.
- PII: Mask in logs (SSN, salary, personal data); encrypt at-rest/in-transit; parameterized queries only.

## Observability
- @PiTimer on controllers/listeners only (entry points); use SetupCentralBusinessProcesses enum.
- Logging: atDebug() for tech details, atInfo() for events, atWarn() for recoverable, atError() for unrecoverable.
- Sanitize PII; use MDC for tracing.

## Testing
- Unit: Domain/use cases with mocks.
- Integration: Repositories + Testcontainers.
- Contract: Spring Cloud Contract.
- Cucumber: Cross-cutting features only.

## Naming & Conventions
- UseCase: <Concept><Action>UseCase.
- Repository: <Concept>RepositoryAdapter.
- Entities: <Concept>Entity.
- IDs: <Concept>Id/Oid.
- Lombok: @Getter/@Setter/@Builder/@ToString/@EqualsAndHashCode; avoid @Data; no manual equals/hashCode.

## Mapping
- toDomain() in DTOs; fromDomain() static in DTOs.
- No mappers in domain; pure transformations.
- Use Optional for nullables; streams for collections.

## Prohibitions
- No new persistence/security tech without approval.
- No unchecked exceptions outside hierarchy.
- No circular deps or entity exposure in APIs.
- No static imports or
- No usage of deprecated code or methods.