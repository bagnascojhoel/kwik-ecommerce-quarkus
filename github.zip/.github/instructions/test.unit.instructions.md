---
applyTo: '**/test/**/*.java'
---

## Affected Layers
These instructions apply to unit tests for **domain**, **application**, and **infrastructure** layers. Do not generate unit tests for **presentation** layers.

## Test Instructions
Write maintainable automated tests covering functionality and edge cases using appropriate strategies (unit, integration, component, contract). Follow Given-When-Then structure for behavior testing.

## Testing Priorities
1. **Unit Tests**: Fast, isolated tests for methods/classes without dependencies. Use JUnit 5 + Mockito + AssertJ. Avoid Spring context.
2. **Integration Tests**: Test component interactions with real dependencies (e.g., MockServer for APIs). Use Spring Boot Test.
4. **Contract Tests**: Verify API contracts. Use Spring Cloud Contract + WireMock when APIs change.
5. **Architecture Tests**: Enforce boundaries. Use ArchUnit.

## Frameworks
- **JUnit 5**: Core framework; use `@ExtendWith(MockitoExtension.class)`, `@ParameterizedTest`, `@Nested`.
- **Mockito**: Mock dependencies; prefer `@Mock`/`@InjectMocks` over manual creation.
- **AssertJ**: Fluent assertions; use `Assertions.assertThat()` (avoid static imports).
- **Spring Boot Test**: Full context with `@SpringBootTest`; layer-specific with `@WebMvcTest`, `@DataJpaTest`.
- **Testcontainers**: Docker-based testing; use `@Testcontainers` + `@Container` for databases.
- **ArchUnit**: Validate architecture; define layers and rules with `layeredArchitecture()`.

## Maintainability
- Use fixtures from DomainObjectConstants and other Fixture classes for test data; leverage `.toBuilder()` for variations.
- Group tests by method with `@Nested` classes.
- Name tests: `given<Context>_when<Behavior>_then<ExpectedOutcome>`.
- Use `actual` for results, `expected` for expectations.
- Do not add divider comments (e.g. `// Given // When // Then`)

## Key Patterns
- **Unit Test**: `@ExtendWith(MockitoExtension.class)`; mock dependencies; verify interactions.
- **Integration Test**: Use Testcontainers for databases; `@Transactional` for isolation.
- **Contract Test**: Define in Groovy DSL; base classes extend `AbstractContractBase`.
- **Architecture Test**: Import classes once in `@BeforeAll`; enforce layer rules with `because()` explanations.
- **Always use fixed dates**: Use `LocalDate.parse("2025-01-01")` or `LocalDate.now(clock)` with `ClockMocker`
so it always return a fixed date.

## Test Data
- **Unit/Integration**: In-memory or fixtures.
- **Component**: Testcontainers with SQL scripts.

## Execution
- All tests: `./gradlew unitTest`
- Specific unit test: `./gradlew unitTest --tests "*TestClassName"`
- Validation: `./gradlew compileTestJava checkstyleTest checkstyleContractTest`
- Coverage: `./gradlew unitTest jacocoTestReport`

## Coverage Verification
After writing tests, verify coverage to identify missing scenarios:
1. Generate reports for changed impacted test files: `./gradlew unitTest --tests "*TestClassName" jacocoTestReport`
2. Open: `build/reports/jacoco/test/jacocoTestReport.xml`
3. Review: Identify uncovered lines/branches (red/yellow highlights)
4. Add tests: Cover missing scenarios (error paths, edge cases, conditional branches)
5. Target: Aim for >90% line coverage and 100% branch coverage on business logic