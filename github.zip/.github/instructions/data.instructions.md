---
applyTo: 'data/**/*'
---

# Data Layer Standards

This document outlines the standards and conventions for the data layer in the setup-central project. The data layer manages schema evolution using event-driven architecture, ensuring idempotent, chronological migrations with audit trails and performance optimization.

## Overview

The data layer uses Liquibase 4.x.x for database migrations, targeting MariaDB/MySQL-compatible databases. Migrations are organized chronologically and must be idempotent to support safe rollbacks and multi-environment deployments.

## Key Structure

- **Changelog Directory**: `data/setup_central/changelog/` organized by `YYYY/MM/` for migration files.
- **Master Changelog**: `db-changelog-master.xml` includes all migration files in chronological order.
- **Resources**: `liquibase.properties` for database connection configuration.

## Core Conventions

- **Naming Conventions**:
  - Migration files: `YYYY/MM/descriptive_action_on_table_name.xml`
  - Changesets: Use IDs like `YYYYMMDDNN` or descriptive identifiers.
- **Audit Columns**: Include standard fields (`created_by`, `created_on`, `modified_by`, `modified_on`) on all entity tables.
- **Primary Keys**: UUID strings as `VARCHAR(36)`.
- **Foreign Keys**: Named as `fk_[child]_[parent]`.
- **Indexes**: Named as `idx_[table_name]_[column_names]`; prioritize on foreign key and frequently queried columns.
- **Data Types**:
  - UUIDs: `VARCHAR(36)`
  - Complex data: `JSON`
  - Dates: `TIMESTAMP(6)`

## Command

We use `./gradlew local update` to run the migrations locally.

## Migration Best Practices

- **PreConditions**: Use `preConditions` (e.g., `tableExists`, `columnExists`) for idempotency; set `onFail="MARK_RAN"`.
- **Multi-Database Support**: Use properties like `now` for compatibility with MySQL/MariaDB/PostgreSQL.
- **Testing and Updates**: Test migrations locally; avoid modifying applied changesets; update the master changelog chronologically.
- **Prohibitions**: Do not drop tables/columns without proper migrations, bypass preConditions, or use database-specific SQL without abstraction.

## Safety and Performance

- **Rollbacks**: Include rollbacks where possible; monitor for foreign key and index conflicts.
- **Indexing**: Index join and query columns; batch large migrations to avoid performance issues.
- **Integration**: Update JPA mappings after schema changes to maintain consistency.

## Best Practices

- Ensure all migrations are chronological and idempotent.
- Document changes in changeset comments.
- Follow existing patterns for consistency across the project.

